package org.main.humain;

public enum Specialites {
    Informatique,
    Mathematiques,
    Genie_Logiciel,
    Reseaux_Informatique,
    Intelligence_Artificielle,
    NULL
}


