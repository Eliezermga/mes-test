package org.main.humain;

public enum Sexe {
    M,
    F,
    NULL
}



