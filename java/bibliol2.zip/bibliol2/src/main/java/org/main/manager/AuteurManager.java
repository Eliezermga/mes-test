package org.main.manager;

import org.main.humain.Auteur;

import java.util.List;

public interface AuteurManager {
    List<Auteur> getAuteur();
    void updateAuteur(Auteur a);
    void ajoutAuteur (Auteur a);
    void deleteAuteur (int id);
    Auteur findAuteurById (int id);

}

