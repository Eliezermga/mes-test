package org.main.humain;

public class Auteur {
    private int id;
    private String nom;
    private String email;
    private Sexe Sexe;
    private Specialites Specialites;

    public org.main.humain.Sexe getSexe() {
        return Sexe;
    }

    public void setSexe(org.main.humain.Sexe sexe) {
        Sexe = sexe;
    }

    public org.main.humain.Specialites getSpecialites() {
        return Specialites;
    }

    public void setSpecialites(org.main.humain.Specialites specialites) {
        Specialites = specialites;
    }

    public int getId(){
        return this.id;
    }
    public void setId(int id){
        this.id = id;
    }

    public String getEmail(){
        return this.email;
    }
    public void setEmail(String email){
        this.email = email;
    }

    public String getNom() {
        return this.nom;
    }
    public void setNom(String nom){
        this.nom = nom;
    }

}


