package org.main;

import org.main.data.Connexion;
import org.main.humain.*;
//import org.main.lib.Livre;
import org.main.manager.*;

import java.sql.Date;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        /*AuteurManagerService auteurService = new AuteurManagerService();
        Auteur a = new Auteur();
        a.setNom("Greg");
        a.setEmail("greg@gmail.com");
        auteurService.ajoutAuteur(a);
        List<Auteur> auteurs = auteurService.getAuteur();
        for (Auteur auteur : auteurs) {
            System.out.println("Nom: " + auteur.getNom() + ", Email: " + auteur.getEmail());
        }

        LivreManagerImp livreService = new LivreManagerImp();
        Livre b = new Livre();
        b.setTitre("Les femmes");
        b.setDatePublication(new Date(1024, 1, 20));
        b.setNbrePages(180);
        livreService.ajoutLivre(b);
        List<Livre> livres = livreService.getLivre();
        for (Livre livre : livres) {
            System.out.println("Titre: " + livre.getTitre() + ", Date de publication: " + livre.getDatePublication() + ", Nombre de pages: " + livre.getNbrePages());
        }*/

        /*AuteurManagerService updateAuteurService = new AuteurManagerService();
        Auteur c = new Auteur();
        c.setId(1); //
        c.setNom("eli");
        c.setEmail("eli@gmail.com");
        updateAuteurService.updateAuteur(c);
        List<Auteur> auteurs = updateAuteurService.getAuteur();
        for (Auteur auteur : auteurs){
            System.out.println("Nom: " + auteur.getNom() + ", Email: " + auteur.getEmail());
        }

        LivreManagerImp updateLivreService = new LivreManagerImp();
        Livre d = new Livre();
        d.setId(1);
        d.setTitre("Les hommes");
        d.setDatePublication(new Date(2024, 8, 19));
        d.setNbrePages(100);
        updateLivreService.updateLivre(d);
        List<Livre> livres = updateLivreService.getLivre();
        for (Livre livre : livres){
            System.out.println("Titre: " + livre.getTitre() + ", Date de publication: " + livre.getDatePublication() + ", Nombre de pages: " + livre.getNbrePages());
        }*/

        /*AuteurManagerService deleteAuteurService = new AuteurManagerService();
        Auteur f = new Auteur();
        f.setId(2);
        deleteAuteurService.deleteAuteur(f);
        List<Auteur> auteurss = deleteAuteurService.getAuteur();
        for (Auteur auteur : auteurss){
            System.out.println("Nom: " + auteur.getNom() + ", Email: " + auteur.getEmail() + "Supprimé");
        }

        LivreManagerImp deleteLivreService = new LivreManagerImp();
        Livre g = new Livre();
        g.setId(2);
        deleteLivreService.deleteLivre(g);
        List<Livre> livress = deleteLivreService.getLivre();
        for (Livre livre : livress){
            System.out.println("Titre: " + livre.getTitre() + ", Date de publication: " + livre.getDatePublication() + ", Nombre de pages: " + livre.getNbrePages());
        }*/

    }
}