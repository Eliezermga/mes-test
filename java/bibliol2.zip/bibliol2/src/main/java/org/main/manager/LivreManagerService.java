package org.main.manager;

import org.main.data.Connexion;
import org.main.librairie.Livre;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LivreManagerService implements LivreManager {
    Connexion connexion = new Connexion();
    @Override
    public List<Livre> getLivre() {
        List<Livre> livres = new ArrayList<>();
        try {
            Statement statement = connexion.getCon().createStatement();
            ResultSet resultSet = statement.executeQuery("select * FROM livre");
            int code;
            String title;
            while (resultSet.next()){
                Livre livre = new Livre();
                livre.setId(resultSet.getInt("id"));
                livre.setTitre(resultSet.getString("titre"));
                livre.setDatePublication(resultSet.getDate("datepublication"));
                livre.setNombrePages(resultSet.getInt("nbrepages"));
                livres.add(livre);
            }
            resultSet.close();
            statement.close();
            return livres;
        }catch (Exception exception){
            throw new RuntimeException();
        }

    }

    @Override
    public void ajoutLivre(Livre a) {
        String query = "INSERT INTO livre (id,titre, datepublication, nbrepages) VALUES (? , ? , ?, ?)";
        try {
            PreparedStatement state = connexion.getCon().prepareStatement(query);
            state.setInt(1, a.getId());
            state.setString( 2, a.getTitre());
            state.setDate(3, a.getDatePublication());
            state.setInt(4, a.getNombrePages());
            state.execute();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        }

    }

    @Override
    public void updateLivre(Livre c) {
        String query = "UPDATE livre SET titre = ?, datepublication = ?, nbrepages = ?  WHERE id = ?";
        try (PreparedStatement state = connexion.getCon().prepareStatement(query)) {
            state.setString(1, c.getTitre());
            state.setDate(2, c.getDatePublication());
            state.setInt(3, c.getNombrePages());
            state.setInt(4, c.getId());
            state.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteLivre(int id){
        String query = "DELETE FROM livre WHERE id = ?";
        try {
            PreparedStatement state = connexion.getCon().prepareStatement(query);
            state.setInt( 1, id);
            state.execute();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public Livre findLivreById(int id) {
        return null;
    }

}
