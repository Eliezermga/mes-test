package org.main.manager;

import org.main.data.Connexion;
import org.main.humain.Auteur;
import org.main.humain.Sexe;
import org.main.humain.Specialites;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AuteurManagerService implements AuteurManager {
    Connexion connexion = new Connexion();
    @Override
    public List<Auteur> getAuteur() {
        List<Auteur> auteurs = new ArrayList<>();
        try {
            Statement statement = connexion.getCon().createStatement();
            ResultSet resultSet = statement.executeQuery("select * FROM auteur");
            int code;
            String title;
            while (resultSet.next()){
                Auteur auteur = new Auteur();
                auteur.setId(resultSet.getInt("id"));
                auteur.setNom(resultSet.getString("nom"));
                auteur.setEmail(resultSet.getString("email"));
                try{
                    auteur.setSexe(Sexe.valueOf(resultSet.getString("sexe")));
                }catch (Exception e){
                    auteur.setSexe(Sexe.NULL);
                }
                try{
                    auteur.setSpecialites(Specialites.valueOf(resultSet.getString("specialites")));
                }catch(Exception e){
                    auteur.setSpecialites(Specialites.NULL);
                }
                auteurs.add(auteur);
            }
            System.out.println(auteurs.size());
            resultSet.close();
            statement.close();
            return auteurs;
        }catch (Exception exception){
            throw new RuntimeException();
        }

    }

    @Override
    public void updateAuteur(Auteur c) {
        String query = "UPDATE auteur SET nom = ?, email = ?, sexe =?, specialites=? WHERE id = ?";
        try (PreparedStatement state = connexion.getCon().prepareStatement(query)) {
            state.setString(1, c.getNom());
            state.setString(2, c.getEmail());
            state.setInt(5, c.getId());
            state.setString(3, c.getSexe().toString());
            state.setString(4, c.getSpecialites().toString());
            state.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        }
    }


    @Override
    public void ajoutAuteur(Auteur a) {
        String query = "INSERT INTO auteur (nom, email, sexe, specialites) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement state = connexion.getCon().prepareStatement(query);
            state.setString( 1, a.getNom());
            state.setString(2, a.getEmail());
            state.setString(3, a.getSexe().toString());
            state.setString(4, a.getSpecialites().toString());
            state.execute();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        }

    }

    @Override
    public void deleteAuteur(int id){
        String query = "DELETE FROM auteur WHERE id = ?";
        try {
            PreparedStatement state = connexion.getCon().prepareStatement(query);
            state.setInt( 1, id);
            state.execute();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public Auteur findAuteurById(int id) {
        return null;
    }

}
