package org.main.UI;

import org.jdatepicker.JDatePicker;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;
import org.main.librairie.Livre;
import org.main.manager.LivreManagerService;
import org.main.utils.DateLabelFormatter;
import org.main.utils.DocumentUtils;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class UILivre extends JFrame {
    private JLabel labelId;
    private JLabel labelTitre;
    private JLabel labelDatePublication;
    private JLabel labelNbrePages;
    private JTextField textFieldId;
    private JTextField textFieldTitre;
    private JTextField textFieldNbrePages;
    private JTextField textFielDatePublication;


    private JDatePicker publicationDatePicker;
    private JSpinner spinnerNombrePage;
    private Date selectedDate;
    private SimpleDateFormat dateFormat;
    private UtilDateModel UtilDateModel;
    private SpinnerModel spinnerModel;

    private JButton buttonAdd;
    private JButton buttonDelete;
    private JButton buttonUpdate;
    private JButton buttonPrint;
    private JTable table;
    private JPanel panel;
    private DefaultTableModel model;
    private String[] columns = {"ID", "TITRE", "DATEPUBLICATION", "NBRE PAGES"};
    private JScrollPane scrollPane;
    private LivreManagerService service = new LivreManagerService();

    public UILivre(){
        init();
        setTitle("Interface livre");
        setSize(600, 600);
        setLocationRelativeTo(null);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        buttonAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(buttonAdd.getText().equals("Nouveau")) {
                    emptyField();
                } else {

                    Livre livre = new Livre();
                    livre.setId(Integer.parseInt(textFieldId.getText()));
                    livre.setTitre(textFieldTitre.getText());
                    //livre.setDatePublication(textFieldDatePublication.getText());
                    //livre.setNombrePages(Integer.parseInt(textFieldNbrePages.getText()));
                    try {
                        service.ajoutLivre(livre);
                        JOptionPane.showMessageDialog(null, "Livre ajouté!");
                        actualiser();
                        buttonAdd.setText("Nouveau");

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Erreur d'ajout de l'livre");
                    }
                }

            }

            private void emptyField() {
            }
        });
        buttonUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Livre livre = new Livre();
                livre.setId(Integer.parseInt(textFieldId.getText()));
                livre.setTitre(textFieldTitre.getText());
                //livre.setDatePublication(textFieldDatePublication.getText());
                //livre.setNombrePages(Integer.parseInt(textFieldNbrepages.getText()));
                try{
                    service.updateLivre(livre);
                    JOptionPane.showMessageDialog(null,"Livre mis a jour!");
                    actualiser();
                    buttonAdd.setText("Nouveau");

                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,"Erreur de mise a jour de l'livre");
                }
            }
        });

        buttonDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(textFieldId.getText());
                try{
                    service.deleteLivre(id);
                    JOptionPane.showMessageDialog(null,"Livre supprimé!");
                    actualiser();
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,"Erreur de suppression de l'livre");
                }
            }
        });
        buttonPrint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                float[]widths={20,90,50,30};
                new DocumentUtils(columns, model, "livres", widths).print();
            }
        });
    }

    public static void main(String args[]){
        new UILivre();
    }

    private void init(){
        panel = new JPanel(new GridBagLayout());
        labelId = new JLabel("Id");
        panel.add(labelId);
        labelTitre = new JLabel("Titre");
        labelDatePublication = new JLabel("DatePublication");
        labelNbrePages = new JLabel("NbrePages");
        textFieldId = new JTextField("-1", 5);
        textFieldId.setEditable(true);
        textFieldTitre = new JTextField(30);

        dateFormat = new SimpleDateFormat("yyyy--mm-dd");
        UtilDateModel = new UtilDateModel();
        Properties properties = new Properties();
        properties.put("text.today", "Today");
        properties.put("text.month", "Month");
        properties.put("text.year", "Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(UtilDateModel, properties);
        publicationDatePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());

        publicationDatePicker.addActionListener(e -> {
            java.util.Date date = (java.util.Date)publicationDatePicker.getModel().getValue();
            selectedDate = new Date(date.getTime());
        });
        spinnerModel = new SpinnerNumberModel(100, 0, 2000, 1);
        spinnerNombrePage = new JSpinner(spinnerModel);
        spinnerNombrePage.setPreferredSize(new Dimension(80, 30));


        buttonAdd = new JButton("Enregistrer");
        buttonDelete = new JButton("Supprimer");
        buttonUpdate = new JButton("Update");
        buttonPrint = new JButton("Imprimer");
        buttonUpdate.setEnabled(false);
        buttonDelete.setEnabled(false);
        model = new DefaultTableModel(columns, 0){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        actualiser();
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        ListSelectionModel selectionModel = table.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (e.getValueIsAdjusting()){
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                        String titre = table.getValueAt(selectedRow, 1).toString();
                        /*String datePublication = table.getValueAt(selectedRow, 2).toString();
                        int nbrePages = Integer.parseInt(table.getValueAt(selectedRow, 3).toString());*/
                        textFieldId.setText(String.valueOf(id));
                        textFieldTitre.setText(titre);
                        /*textFieldDatePublication.setText(String.valueOf(datePublication));
                        textFieldNbrepages.setText(String.valueOf(nbrePages));*/
                        buttonUpdate.setEnabled(true);
                        buttonDelete.setEnabled(true);
                        buttonAdd.setText("Nouveau");

                    }
                }
            }
        });
        scrollPane = new JScrollPane(table);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(1, 1, 1, 1);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(labelId, gbc);
        gbc.gridx = 1;

        panel.add(textFieldId, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(labelTitre, gbc);
        gbc.gridx = 1;
        panel.add(textFieldTitre, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(labelDatePublication, gbc);
        gbc.gridx = 1;
        panel.add((Component) publicationDatePicker, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(labelNbrePages, gbc);
        gbc.gridx = 1;
        panel.add(spinnerNombrePage, gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(buttonAdd, gbc);
        gbc.gridx = 1;
        panel.add(buttonUpdate, gbc);
        gbc.gridx = 2;
        panel.add(buttonDelete, gbc);
        gbc.gridx = 3;
        panel.add(buttonPrint ,gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 4;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(scrollPane, gbc);
        this.setContentPane(panel);
    }
    private void actualiser(){
        try {
            model.setRowCount(0);
            for (Livre livre: service.getLivre()){
                model.addRow(new Object[]{livre.getId(), livre.getTitre(), livre.getDatePublication(), livre.getNombrePages()});
            }
            model.fireTableDataChanged();
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
