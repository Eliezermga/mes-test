package org.main.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class UIMenu extends JFrame {
    public UIMenu(){
        init();
        setTitle("Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String[] args) {
        new UIMenu();
    }
    private void init(){
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");

        JMenuItem livreItem = new JMenuItem("Livre");
        JMenuItem auteurItem = new JMenuItem("Auteur");
        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem publicationItem = new JMenuItem("Publication");

        livreItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UILivre uiLivre = new UILivre();
                uiLivre.setVisible(true);
            }
        });
        auteurItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UIAuteur auteur = new UIAuteur();
                auteur.setVisible(true);
            }
        });
        publicationItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UIPublication publication = null;
                try {
                    publication = new UIPublication();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                publication.setVisible(true);
            }
        });
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int option = JOptionPane.showConfirmDialog(null, "Voulez vous vraiment quitter l'application?");
                if(option == JOptionPane.YES_OPTION){
                    System.exit(0);
                }
            }
        });

        JMenu operationMenu = new JMenu("Operation");
        operationMenu.add(livreItem);
        operationMenu.add(auteurItem);
        operationMenu.add(publicationItem);
        operationMenu.addSeparator();

        operationMenu.add(exitItem);
        menuBar.add(operationMenu);
        JPanel panel = new JPanel();
        panel.add(menuBar);
        this.setContentPane(panel);

    }
}
