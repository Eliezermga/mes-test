package org.main.manager;

import org.main.data.Connexion;
import org.main.humain.Auteur;
import org.main.humain.Sexe;
import org.main.humain.Specialites;
import org.main.librairie.Livre;
import org.main.librairie.Publication;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PublicationManagerService implements PublicationManager {
    private Statement statement;
    private ResultSet resultSet;
    private Connexion connexion = new Connexion();

    @Override
    public List<Publication> getPublications() throws SQLException {
        List<Publication> publications = new ArrayList<>();
        statement = connexion.getCon().createStatement();
        resultSet = statement.executeQuery(
                "SELECT livre.id as id, livre.titre AS titre, GROUP_CONCAT(auteur.nom ORDER BY auteur.nom ASC SEPARATOR ', ') AS auteurs FROM     publication JOIN     auteur ON publication.idAuteur = auteur.id JOIN     livre ON publication.idLivre = livre.id GROUP BY     livre.id ORDER BY     livre.titre ASC;");
        int code;
        String title;
        Publication publication;
        while (resultSet.next()) {
            publication = new Publication();
            publication.setId(resultSet.getInt("id"));
            publication.setTitre(resultSet.getString("titre"));
            publication.setAuteurs(resultSet.getString("auteurs"));

            publications.add(publication);
        }
        resultSet.close();
        statement.close();
        return publications;
    }

    @Override
    public void savePublication(int idLivre, List<Integer> idAuteurs) throws SQLException {
        String query = "INSERT INTO publication (idAuteur, idLivre) VALUES (?, ?)";
        PreparedStatement state = connexion.getCon().prepareStatement(query);
        for (int id : idAuteurs) {
            state.setInt (1, id);
            state.setInt (2, idLivre);
            state.execute();
        }

    }

}
