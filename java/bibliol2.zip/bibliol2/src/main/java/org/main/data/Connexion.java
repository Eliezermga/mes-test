package org.main.data;

import org.main.humain.Auteur;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Connexion {
    private Connection con;
    static String DB="bibliotheque";
    static String USER="root";
    static String PWD="";
    static String HOST="localhost";
    static String PORT="3306";
    static String URL="jdbc:mysql://" + HOST + ":" + PORT + "/" + DB;

    public Connexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con= DriverManager.getConnection(URL,USER,PWD);
        } catch (Exception exception) {
            System.out.println(exception);
            con = null;
        }
    }

    public  Connection getCon() {
        return con;
    }

    public void updateAuteur(Auteur auteur) {

    }
}
