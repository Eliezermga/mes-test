package org.main.humain;

public enum Specialites {
    INFORMATIQUE,
    MATHEMATIQUE,
    GENIE_LOGICIEL,
    RESEAUX_INFORMATQUE,
    INTELLIGENCE_ARTIFICELLE, NULL,
}
