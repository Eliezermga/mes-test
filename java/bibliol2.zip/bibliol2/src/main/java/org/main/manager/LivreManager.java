package org.main.manager;

import org.main.librairie.Livre;

import java.util.List;

public interface LivreManager {
    List<Livre> getLivre();
    void updateLivre(Livre a);
    void ajoutLivre (Livre a);
    void deleteLivre (int id);
    Livre findLivreById (int id);

}
